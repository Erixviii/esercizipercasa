﻿namespace Clinica_Dente
{
    class Specializzazione 
    {

        public string Nome { get; set; }
        public int Id { get; set; }
    }
}
