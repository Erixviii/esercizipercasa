﻿namespace Clinica_Dente
{
    class Patologia 
    {

        public string Nome { get; set; }
        public int Id { get; set; }
    }
}
