﻿using System;

namespace Clinica_Dente
{
    class Appuntamento
    {

        public DateTime Data { get; set; }
        public string Paziente { get; set; }
        public string Medico { get; set; }
    }
}
